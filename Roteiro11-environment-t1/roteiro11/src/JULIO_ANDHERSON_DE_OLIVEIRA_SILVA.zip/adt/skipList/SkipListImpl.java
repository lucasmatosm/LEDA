package adt.skipList;

public class SkipListImpl<V> implements SkipList<V> {

	protected SkipNode<V> root;
	protected int level;
	protected int maxLevel;

	//SET THIS VALUE TO TRUE IF YOU ARE IMPLEMENTING MAX_LEVEL = LEVEL
	//SET THIS VALUE TO FALSE IF YOU ARE IMPLEMENTING MAX_LEVEL != LEVEL
	protected boolean useMaxLevelAsLevel = false;
	protected double probability = 0.5; 
	protected SkipNode<V> NIL;
	
	public SkipListImpl(int maxLevel) {
		if(useMaxLevelAsLevel){
			this.level = maxLevel;
		}else{
			this.level = 1;
		}
		this.maxLevel = maxLevel;
		root = new SkipNode(Integer.MIN_VALUE, maxLevel, new Integer(Integer.MIN_VALUE));
		NIL = new SkipNode(Integer.MAX_VALUE, maxLevel, new Integer(Integer.MAX_VALUE));
		connectRootToNil();
	}
	
	/**
	 * Faz a ligacao inicial entre os apontadores forward do ROOT e o NIL
	 * Caso esteja-se usando o level do ROOT igual ao maxLevel esse metodo deve
	 * conectar todos os forward. Senao o ROOT eh inicializado com 
	 * level=1 e o metodo deve conectar apenas o forward[0].  
	 */
	private void connectRootToNil(){
		for(int i = 0; i < level; i++){
			root.forward[i] = NIL;
		}
	}
	
	/**
	 * Metodo que gera uma altura aleatoria para ser atribuida a um novo no no metodo
	 * insert(int,V) 
	 */
	private int randomLevel(){
		int randomLevel = 1;
		double random = Math.random();
		while(Math.random() <= probability && randomLevel < maxLevel){
			randomLevel = randomLevel + 1;
		}
		return randomLevel;
	}
	
	@Override 
    public void insert(int key, V newValue) { 
		insert(key, newValue, randomLevel());
    } 
 
	@Override
    public void insert(int key, V newValue, int height) {
		SkipNode<V>[] update = new SkipNode[maxLevel];
        SkipNode<V> x = root;
        for (int i = level -1; i > -1; i--) {
        	while ((x.forward[i] != null) &&(x.forward[i].key < key)){
        		x = x.forward[i];
        	}
            update[i] = x;
        }
        x = x.forward[0];
        if(x.key == key){
        	x.satteliteData = newValue;
        }else{
            int v = height;
            if(v > level){
            	for (int i = level + 1; i > v; i--) {
            		update[i] = root;
            	}
            	level = v;
            }
            x = new SkipNode<V>(key, v, newValue);
            for (int i = 0; i < v; i++) {
            	if(update[i] != null){
            		x.forward[i] = update[i].forward[i];
            		update[i].forward[i] = x;
            	}
            }
        }
    }

    @Override
    public void remove(int key) {
        SkipNode<V>[] update = new SkipNode[maxLevel];
        SkipNode<V> x = root;
        for (int i = level -1; i > 0; i--) {
            while ((x.forward[i] != null) && (x.forward[i].key < key)) {
                x = x.forward[i];
            }
            update[i] = x;
        }
        x = x.forward[0];
        if (x.key == key) {
            for (int i = 0; i < level; i++) {
                if (update[i].forward[i] != x) {
                    break;
                }
                update[i].forward[i] = x.forward[i];
            }
            while ((level > 0) && (root.forward[level] == NIL)) {
                level--;
            }
        }
    }

	@Override
	public int height() {
		return level;
	}
	
	@Override
	public SkipNode<V> search(int key) {
		SkipNode<V> Auxiliar = root;
		for(int i = level - 1; i > 0; i --){
            while ((Auxiliar.forward[i] != null) && (Auxiliar.forward[i].key < key)) {
				Auxiliar = Auxiliar.forward[i];
			}
		}
		Auxiliar = Auxiliar.forward[0];
		if(Auxiliar.key == key){
			SkipNode<V> satteliteData = (SkipNode<V>) Auxiliar.satteliteData;
			return satteliteData;
		}
		return null;
	}

	@Override
	public int size(){
		SkipNode<V> Auxiliar = root;
		int Tamanho = 0;
		while(!(Auxiliar.forward[0] == NIL)){
			Auxiliar = Auxiliar.forward[0];
			Tamanho ++;
		}
		return Tamanho;
	}

    @Override
    public SkipNode<V>[] toArray() {
        SkipNode[] Array = new SkipNode[size() + 2]; //+2 porque inclui ROOT e NIL
        SkipNode<V> Auxiliar = this.root;
        int indice = 0;
        while (!(Auxiliar == NIL)){
        	Array[indice] = Auxiliar;
            Auxiliar = Auxiliar.forward[0];
            indice++;
        }
        Array[indice] = Auxiliar;
        return Array;
    }
}
