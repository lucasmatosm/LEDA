package adt.splaytree;

import adt.avltree.AVLTreeImpl;
import adt.bst.BSTNode;

public class SplayTreeImpl<T extends Comparable<T>> extends AVLTreeImpl<T> implements
		SplayTree<T> {
	
	private void splay(BSTNode<T> node) {
		if (node.getParent() == root) {
			if (node == node.getParent().getLeft()) {
				rightRotation(root);
			} else {
				leftRotation(root);
			}
		} else if ((isRight(node)) && (isRight((BSTNode<T>) node.getParent()))) {
			leftRotation((BSTNode<T>) node.getParent().getParent());
			leftRotation((BSTNode<T>) node.getParent());
		} else if ((isLeft(node)) && (isLeft((BSTNode<T>) node.getParent()))) {
			rightRotation((BSTNode<T>) node.getParent().getParent());
			rightRotation((BSTNode<T>) node.getParent());
		} else {
			if ((isRight(node)) && (isLeft((BSTNode<T>) node.getParent()))) {
				leftRotation((BSTNode<T>) node.getParent());
				rightRotation((BSTNode<T>) node.getParent().getParent());
			} else {
				rightRotation((BSTNode<T>) node.getParent());
				leftRotation((BSTNode<T>) node.getParent().getParent());
			}
		}
	}

	private boolean isLeft(BSTNode<T> node) {
		return node == node.getParent().getLeft();
	}

	private boolean isRight(BSTNode<T> node) {
		return node == node.getParent().getRight();
	}

	@Override
	public void insert(T valor) {
		insertRecursive(root, valor);
		splay(searchRecursive(root, valor));
	}

	private void insertRecursive(BSTNode<T> node, T element) {
		if (node.isEmpty()) {
			node.setData(element);
			node.setLeft(new BSTNode<T>());
			node.setRight(new BSTNode<T>());
			node.getLeft().setParent(node);
			node.getRight().setParent(node);
		} 
		
		else {
			if (node.getData().compareTo(element) > 0){
				insertRecursive((BSTNode<T>)node.getLeft(), element);
			}
			else{
				insertRecursive((BSTNode<T>) node.getRight(), element);
			}
		}
	}
	
	@Override
	public BSTNode<T> search(T chave) {
		BSTNode<T> no = searchRecursive(root, chave);
		if (!no.isEmpty()) {
			splay(no);
		} else {
			splay((BSTNode<T>) no.getParent());
		}
		return searchRecursive(root, chave);
	}
	
    protected BSTNode<T> searchRecursive(BSTNode<T> node, T key) {
        BSTNode<T> result = node;
        if (key != null) {
            if (!node.isEmpty()) {
                if (key.compareTo(node.getData()) == 0) {
                    result = node;
                } else if (key.compareTo(node.getData()) < 0) {
                    result = searchRecursive((BSTNode<T>) node.getLeft(), key);
                } else {
                    result = searchRecursive((BSTNode<T>) node.getRight(), key);
                }
            }
        }

        return result;
    }

	@Override
	public void remove(T chave) {
		BSTNode<T> node = searchRecursive(root, chave);
		remove((T) node);
		if (!node.equals(root)) {
			splay((BSTNode<T>) node.getParent());
		}
	}
}
