package adt.heap;

public interface MinHeap<T extends Comparable<T>> extends GenericHeap<T>{

		
}
