package sorting.divideAndConquer;

import static org.junit.Assert.*;

import org.junit.Test;

public class QuicksortTest {

	@Test
	public void testSortT0() {
		Integer array[] = {};
		Integer ordered[] = {};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array);
		
		assertArrayEquals(ordered, array);
	}

	@Test
	public void testSortT1() {
		Integer array[] = {13};
		Integer ordered[] = {13};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array);
		
		assertArrayEquals(ordered, array);
	}

	@Test
	public void testSortT2() {
		Integer array[] = {5, 4, 7, 2, 8, 9, 1, 1, 4, 6};
		Integer ordered[] = {1, 1, 2, 4, 4, 5, 6, 7, 8, 9};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array);
		
		assertArrayEquals(ordered, array);
	}
	
	@Test
	public void testSortT3() {
		Integer array[] = {5, 4, 7, 2, 8, 9, 1, 1, 4, 6};
		Integer ordered[] = {1, 1, 2, 4, 4, 5, 6, 7, 8, 9};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, 0, 9);
		
		assertArrayEquals(ordered, array);
	}
	
	@Test
	public void testSortT4() {
		Integer array[] = {5, 4, 7, 2, 8, 9, 1, 1, 4, 6};
		Integer ordered[] = {5, 2, 4, 7, 8, 9, 1, 1, 4, 6};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, 1, 4);
		
		assertArrayEquals(ordered, array);
	}
	
	@Test
	public void testSortT5() {
		Integer array[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Integer ordered[] = {-7, -1, 1, 2, 4, 4, 5, 6, 8, 9};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array);
		
		assertArrayEquals(ordered, array);
	}

	@Test
	public void testSortT6() {
		Integer array[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Integer ordered[] = {-7, -1, 1, 2, 4, 4, 5, 6, 8, 9};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, 0, 9);
		
		assertArrayEquals(ordered, array);
	}

	@Test
	public void testSortT7() {
		Integer array[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Integer ordered[] = {5, 4, -7, 2, -1, 1, 4, 6, 8, 9};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, 4, 9);
		
		assertArrayEquals(ordered, array);
	}

	@Test
	public void testSortT8() {
		Integer array[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Integer ordered[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, -1, 9);
		
		assertArrayEquals(ordered, array);
	}

	@Test
	public void testSortT9() {
		Integer array[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Integer ordered[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, 0, -1);
		
		assertArrayEquals(ordered, array);
	}

	@Test
	public void testSortT10() {
		Integer array[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Integer ordered[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, 5, 10);
		
		assertArrayEquals(ordered, array);
	}
	
	@Test
	public void testSortT11() {
		Integer array[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Integer ordered[] = {5, 4, -7, 2, 8, 9, -1, 1, 4, 6};
		Quicksort<Integer> mysort= new Quicksort<>();
		
		mysort.sort(array, 5, 4);
		
		assertArrayEquals(ordered, array);
	}
	
}
