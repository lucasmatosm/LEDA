package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InsertionsortTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testSortTArrayIntInt() {
		fail("Not yet implemented");
	}

}
