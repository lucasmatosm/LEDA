package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SelectionsortTest {

	@Before
	public void setUp() throws Exception {
		int[] testeArray1 = {5, 4, 3, 2, 1};
	}

	@Test
	public void testSortTArrayIntInt() {
	}

}
