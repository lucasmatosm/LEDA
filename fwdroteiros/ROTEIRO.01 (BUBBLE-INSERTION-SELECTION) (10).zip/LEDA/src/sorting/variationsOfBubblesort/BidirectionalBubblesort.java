package sorting.variationsOfBubblesort;

import sorting.SortingImpl;

/**
 * This bubblesort variation pushes the greatest element to the right and (walking from left to right), 
 * after that, it pushes the smallest element to the left (walking from right to left). This happens 
 * in a same iteration. The following iterations do the same until the array is completely ordered. 
 * The algorithm must sort the elements from leftIndex to rightIndex (inclusive).  
 */
public class BidirectionalBubblesort<T extends Comparable<T>> extends SortingImpl<T> {

	@Override
	protected void sort(T[] array,int leftIndex, int rightIndex) {
		// TODO Auto-generated method stub

	}

}
