package adt.stack;
 
import static org.junit.Assert.*;
 
import org.junit.Before;
import org.junit.Test;
 
/**
 * 
 * @author Lucas Cavalcante
 *
 */
public class StackImplTest {
    
        StackImpl<String> str = new StackImpl<String>(10);
        StackImpl<Integer> Int = new StackImpl<Integer>(0);
 
        @Before
        public void setUp() throws Exception {
                str.push("0");
        }
 
        @Test
        public void testPush1() {
                try {
                        str.push("a");
                } catch (Exception e) {
                        fail("Unexpected exception caught, array is full? ");
                }
                
        }
        
        @Test
        public void testPush2() {
                try {
                        str.push("1");
                        str.push("2");
                        str.push("3");
                        str.push("4");
                        str.push("5");
                        str.push("6");
                        str.push("7");
                        str.push("8");
                } catch (Exception e) {
                        fail("Unexpected exception caught, why the array is full? ");
                }
                
        }
        
        @Test
        public void testPush3() {
                try {
                        str.push("1");
                        str.push("2");
                        str.push("3");
                        str.push("4");
                        str.push("5");
                        str.push("6");
                        str.push("7");
                        str.push("8");
                        str.push("9");
                        str.push("10");
                        fail("Exception not caught w/ full array. wtf happened w/ IsFull Exception? ");
                } catch (Exception e) {
                        assertTrue(str.top().equals("9"));
                }
                
        }
        
        @Test
        public void testPop1() {
                try {
                        str.push("1");
                        str.push("2");
                        str.push("3");
                        str.push("4");
                        str.push("5");
                        str.push("6");
                        str.push("7");
                        str.push("8");
                        str.push("9");
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        assertTrue(str.top().equals("0"));
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the pop?");
                }
                
        }
        
        @Test
        public void testPop2() {
                try {
                        str.pop();
                        assertTrue(str.isEmpty());
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the pop?");
                }
                
        }
        
        @Test
        public void testPop3() {
                try {
                        str.push("1");
                        str.push("2");
                        str.push("3");
                        str.push("4");
                        str.pop();
                        assertTrue(str.top().equals("3"));
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the pop?");
                }
                
        }
        
        @Test
        public void testPop4() {
                try {
                        str.push("1");
                        str.push("2");
                        str.push("3");
                        str.push("4");
                        str.push("5");
                        str.push("6");
                        str.push("7");
                        str.push("8");
                        str.push("9");
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.pop();
                        str.push("1");
                        str.push("2");
                        str.push("3");
                        str.push("4");
                        str.push("5");
                        str.push("6");
                        str.push("7");
                        str.push("8");
                        str.push("9");
                        assertTrue(str.top().equals("9"));
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the pop?");
                }
                
        }
        
        @Test
        public void testPop5() {
                try {
                        str.pop();
                        str.pop();
                        fail("Exception not caught w/ empty array. wtf happened w/ IsEmpty Exception? ");
                } catch (Exception e) {
                        assertTrue(str.top()== null);
                }
                
        }
 
        @Test
        public void testPush11() {
                try {
                        Int.push(1);
                        fail("Exception not caught, array size is 0 how can you add elements? ");
                } catch (Exception e) {
                        
                }
                
        }
        
}