package adt.queue;
 
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;
 
public class QueueUsingStackTest {
    
        QueueUsingStack<String> str = new QueueUsingStack<String>(10);
        QueueUsingStack<Integer> Int = new QueueUsingStack<Integer>(0);
 
        @Before
        public void setUp() throws Exception {
                str.enqueue("0");
        }
 
        @Test
        public void testenqueue1() {
                try {
                        str.enqueue("a");
                } catch (Exception e) {
                        fail("Unexpected exception caught, array is full? ");
                }
                
        }
        
        @Test
        public void testenqueue2() {
                try {
                        str.enqueue("1");
                        str.enqueue("2");
                        str.enqueue("3");
                        str.enqueue("4");
                        str.enqueue("5");
                        str.enqueue("6");
                        str.enqueue("7");
                        str.enqueue("8");
                } catch (Exception e) {
                        fail("Unexpected exception caught, why the array is full? ");
                }
                
        }
        
        @Test
        public void testenqueue3() {
                try {
                        str.enqueue("1");
                        str.enqueue("2");
                        str.enqueue("3");
                        str.enqueue("4");
                        str.enqueue("5");
                        str.enqueue("6");
                        str.enqueue("7");
                        str.enqueue("8");
                        str.enqueue("9");
                        str.enqueue("10");
                        fail("Exception not caught w/ full array. wtf happened w/ IsFull Exception? ");
                } catch (Exception e) {
                        assertEquals("0", str.head());
                }
                
        }
        
        @Test
        public void testdequeue1() {
                try {
                        str.enqueue("1");
                        str.enqueue("2");
                        str.enqueue("3");
                        str.enqueue("4");
                        str.enqueue("5");
                        str.enqueue("6");
                        str.enqueue("7");
                        str.enqueue("8");
                        str.enqueue("9");
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        assertTrue(str.head().equals("8"));
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the dequeue?");
                }
                
        }
        
        @Test
        public void testdequeue2() {
                try {
                        str.dequeue();
                        assertTrue(str.isEmpty());
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the dequeue?");
                }
                
        }
        
        @Test
        public void testdequeue3() {
                try {
                        str.enqueue("1");
                        str.enqueue("2");
                        str.enqueue("3");
                        str.enqueue("4");
                        str.dequeue();
                        assertTrue(str.head().equals("1"));
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the dequeue?");
                }
                
        }
        
        @Test
        public void testdequeue4() {
                try {
                        str.enqueue("1");
                        str.enqueue("2");
                        str.enqueue("3");
                        str.enqueue("4");
                        str.enqueue("5");
                        str.enqueue("6");
                        str.enqueue("7");
                        str.enqueue("8");
                        str.enqueue("9");
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.dequeue();
                        str.enqueue("1");
                        str.enqueue("2");
                        str.enqueue("3");
                        str.enqueue("4");
                        str.enqueue("5");
                        str.enqueue("6");
                        str.enqueue("7");
                        str.enqueue("8");
                        str.enqueue("9");
                        assertEquals("9",str.head());
                        
                } catch (Exception e) {
                        fail("Unexpected exception caught, wtf are you doing with the dequeue?");
                }
                
        }
        
        @Test
        public void testdequeue5() {
                try {
                        str.dequeue();
                        str.dequeue();
                        fail("Exception not caught w/ empty array. wtf happened w/ IsEmpty Exception? ");
                } catch (Exception e) {
                        assertTrue(str.head()== null);
                }
                
        }
 
        @Test
        public void testenqueue11() {
                try {
                        Int.enqueue(1);
                        fail("Exception not caught, array size is 0 how can you add elements? ");
                } catch (Exception e) {
                        
                }
                
        }
        
}
 