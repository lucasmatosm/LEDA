package adt.skipList;

public class SkipListImpl<V> implements SkipList<V> {

	protected SkipNode<V> root;
	protected int level;
	protected int maxLevel;

	//SET THIS VALUE TO TRUE IF YOU ARE IMPLEMENTING MAX_LEVEL = LEVEL
	//SET THIS VALUE TO FALSE IF YOU ARE IMPLEMENTING MAX_LEVEL != LEVEL
	protected boolean useMaxLevelAsLevel;
	protected double probability = 0.5; 
	protected SkipNode<V> NIL;
	
	public SkipListImpl(int maxLevel) {
		if(useMaxLevelAsLevel){
			this.level = maxLevel;
		}else{
			this.level = 1;
		}
		this.maxLevel = maxLevel;
		root = new SkipNode(Integer.MIN_VALUE, maxLevel, new Integer(Integer.MIN_VALUE));
		NIL = new SkipNode(Integer.MAX_VALUE, maxLevel, new Integer(Integer.MAX_VALUE));
		connectRootToNil();
	}
	
	/**
	 * Faz a ligacao inicial entre os apontadores forward do ROOT e o NIL
	 * Caso esteja-se usando o level do ROOT igual ao maxLevel esse metodo deve
	 * conectar todos os forward. Senao o ROOT eh inicializado com 
	 * level=1 e o metodo deve conectar apenas o forward[0].  
	 */
	private void connectRootToNil(){
		for (int i = 0; i < root.height; i++) {
			root.forward[i] = NIL;
		}
	}
	
	/**
	 * Metodo que gera uma altura aleatoria para ser atribuida a um novo no no metodo
	 * insert(int,V) 
	 */
	private int randomLevel(){
		int randomLevel = 1;
		double random = Math.random();
		while(Math.random() <= probability && randomLevel < maxLevel){
			randomLevel = randomLevel + 1;
		}
		return randomLevel;
	}
	
	@Override
	public void insert(int key, V newValue) {
		insert(key, newValue, randomLevel());
	}

	@Override
	public void insert(int key, V newValue, int height) {
		SkipNode<V>[] update = new SkipNode[maxLevel];
		SkipNode<V> x = this.root;
		for (int i = this.level -1; i > -1; i--) {
			while ((x.forward[i] != null) &&(x.forward[i].key < key)){
				x = x.forward[i];
			}
			update[i] = x;
		}
		x = x.forward[0];
		if(x.key == key){
			x.satteliteData = newValue;
		}else{
			int v = height;
			if(v > this.level){
				for (int i = this.level + 1; i > v; i++) {
					update[i] = this.root;
				}
				this.level = v;
			}
			x = new SkipNode<V>(key, v, newValue);
			for (int i = 0; i < v; i++) {
				if(update[i] != null){
				x.forward[i] = update[i].forward[i];
				update[i].forward[i] = x;
				}
			}
		}
	}

	@Override
    public void remove(int key) {
		SkipNode<V> atual = root;
		SkipNode<V> removido = search(key);
		if(removido != null){
			for (int i = removido.height - 1; i >= 0; i--) {
				while (atual.forward[i].key < key){
					atual = atual.forward[i];
				}
				atual.forward[i] = removido.forward[i]; 
			}
		}
	}

	@Override
	public int height() {
		return level;
	}

	@Override
	public SkipNode<V> search(int key) {
		SkipNode<V> x = this.root;
		for (int i = this.level -1; i >= 0 ; i--) {
			while((x.forward[i] != null) && (x.forward[i].key <= key)){				
				x = x.forward[i];
				if(x.key == key){
					return x;
				}
			}		
		}
		return null;	
	}

	@Override
	public int size(){
		int size = 0;
		SkipNode<V> x = this.root;
		while(! x.forward[0].equals(NIL)){
			x = x.forward[0];
			size++;
		}
		return size;
	}

	@Override
	public SkipNode<V>[] toArray() { //CHAVE-ALTURA
		SkipNode[] array = new SkipNode[size() + 2];
		SkipNode<V> x = this.root;
		int i = 0;
		while(x != NIL){
			array[i] = x;
			x = x.forward[0];
			i++;
		}
		array[i] = x;
		return array;
	}
}
