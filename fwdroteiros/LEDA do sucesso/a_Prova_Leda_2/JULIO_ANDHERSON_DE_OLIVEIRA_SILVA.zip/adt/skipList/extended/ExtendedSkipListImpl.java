package adt.skipList.extended;

import java.util.ArrayList;

import adt.skipList.SkipListImpl;
import adt.skipList.SkipNode;

public class ExtendedSkipListImpl<V> extends SkipListImpl<V> {

	public ExtendedSkipListImpl(int maxLevel) {
		super(maxLevel);
	}
	
	/**
	 * This method must walk down in the forward pointers as the usual search, 
	 * except for when the key of the forward node is equal to the given key, the 
	 * algorithm walks to the right (to that node) and returns it. Otherwise, 
	 * it continues going down in the forward pointers. Thus, the criteria to walk
	 * horizontally is finding a node with a key that is less or equal to the given key.
	 * If there is no node containing the given key, the algorithm returns the NIL node.
	 */
	public SkipNode<V> extendedSearch(int key){
		SkipNode<V> noAuxiliar = this.root;
	    for (int i = this.level - 1; i >= 0; i--) {
	    	while (noAuxiliar.getForward()[i].getKey() <= key) {
	    		noAuxiliar = noAuxiliar.getForward()[i];
	            if (noAuxiliar.getKey() == key){
	            	return noAuxiliar;
	            }
	       }
	    }
	    return NIL;
	}
	
	/**
	 * It uses the extended search to find a node with the given key. If it exists, then the 
	 * algorithm returns the next node in the skip list. Otherwise, the algorithm returns 
	 * the NIL node. 
	 */
	public SkipNode<V> successor(int key){
		SkipNode<V> noPesquisado = extendedSearch(key);
		if(noPesquisado.getKey() == key){
			return noPesquisado.getForward()[0];
		}
		return NIL;
	}
	
	/**
	 * It returns an array containing the nodes of a skip list by height. Thus, first the nodes
	 * with highest height are put in the array (from left to right), then nodes with the next 
	 * highest height are put into the array, and so on. For example, consider the skip list with 
	 * max height 5 and nodes given by [(4,2),[8,3],(10,1),(15,2),(19,1)], where each pair represents 
	 * a node as (key,height). The result of this method would be [(8,3),(4,2),(15,2),(10,1),(19,1)].  
	 */
	public SkipNode<V>[] toArrayByHeight(){ //ALTURA-CHAVE EM ORDEM DECRESCENTE DE ALTURA
        int level = this.level;
        ArrayList<SkipNode<V>> listaOrdenada = new ArrayList<SkipNode<V>>(); 
        SkipNode<V>[] array = this.toArray();
       
        while(listaOrdenada.size() < size()){
        	for(SkipNode<V> no : array){
        		if(no.getHeight() == level){
        			listaOrdenada.add(no);
                }
            }
            level--;
        }
        return (SkipNode<V>[])listaOrdenada.toArray(new SkipNode[0]);
	}
}
