package sorting.quicksort3;

/**
 * The interface describing the algorithm of quicksort median of 3. 
 * The implementation of the algorithm must be in-place!
 */
public interface QuicksortMedianOfThree {
	public void quicksort3(int[] array, int left, int right);
}
