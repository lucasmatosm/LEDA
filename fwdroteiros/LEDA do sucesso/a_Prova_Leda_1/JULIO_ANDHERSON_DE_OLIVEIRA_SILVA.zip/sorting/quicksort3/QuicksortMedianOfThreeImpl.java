package sorting.quicksort3;


public class QuicksortMedianOfThreeImpl implements QuicksortMedianOfThree {
	
	@Override
	public void quicksort3(int[] array, int left, int right) {
		if(left < right && left >= 0){
			medianaDeTres(array,left,right); //vai deixar o pivot na posicao central (middle) entre left e right
			Util.swap(array, array.length / 2, right-1);//coloca o pivot na penultima posicao
			int pivotPosition = partition(array, left, right-1); //particiona o array e coloca o pivot na posicao correta
			quicksort3(array, left, pivotPosition-1); //aplica o quicksort a primeira parte
			quicksort3(array, pivotPosition + 1,right);
		}
	}
	private static void medianaDeTres(int[] array, int left, int right){ // ORDENA O LEFT CENTER E RIGHT
		int pEsq = array[left];
		int pCen = array[array.length / 2];
		int pDir = array[right];

		if(pEsq > pCen || pEsq > pDir){
			if(pEsq > pCen){
				Util.swap(array, left, array.length / 2);
			}if(pEsq > pDir){
				Util.swap(array, left, right);
			}
		}
		if(pCen > pDir || pCen < pEsq){
			if(pCen > pDir){
				Util.swap(array, array.length / 2, right);
			}if(pCen < pEsq){
				Util.swap(array, array.length / 2, left);
			}
		}
	}
	
	private int partition(int[] array, int left, int right){
		int pivot = array[right];
		int i = left;
		int j = right - 1;
		
		while( i <= j ){
			
			while(array[i] < pivot){
				i++;
			}
			while(array[j] > pivot){
				j--;
			}
			if( i < j){
				Util.swap(array, i, j);
			}
		}
		Util.swap(array, i, right);
		return i;
	}

}
