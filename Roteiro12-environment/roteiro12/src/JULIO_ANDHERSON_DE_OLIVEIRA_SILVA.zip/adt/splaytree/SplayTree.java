package adt.splaytree;

import adt.bst.BST;

public interface SplayTree<K extends Comparable<? super K>, V> extends BST<K,V>{
		
}
